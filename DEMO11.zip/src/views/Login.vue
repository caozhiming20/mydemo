<template>
    <div>
      <div @click="handle1">点击获取token</div>
      <div @click="handle2">计算属性+</div>
      <div @click="handle3">计算属性-</div>
      <div @click="handle4">计算属性+10</div>
      <router-link to="/main">如果有token正常跳转，没有跳转道/Login</router-link>
      <div>显示token:{{token}}</div>
      <div>显示count:{{count}}</div>
    </div>
</template>
<script>
  import { getLogin } from '../api/api'
  import {mapGetters, mapActions} from 'vuex'
  export default {
    methods:{
      handle1(){
        this.$store.dispatch('set_Token')
      },
      handle2(){
        this.$store.dispatch('increase')
      },
      handle3(){
        this.$store.dispatch('decrease')
      },
      handle4(){
        this.$store.dispatch('add_count',10)
      }
    },
    computed:mapGetters({
     count:"get_count",
      token:"get_token"
    }),


  }
</script>


<style>
div{
  width: 100px;
  height: 30px;
  margin:20px auto;
  cursor: pointer;
}
</style>
