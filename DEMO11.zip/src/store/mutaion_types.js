export const ADD_COUNT='ADD_COUNT';
export const INCREASE='INCREASE';
export const DECREASE='DECREASE';
export const SET_TOKEN='SET_TOKEN';
export const DEL_TOKEN='DEL_TOKEN';
